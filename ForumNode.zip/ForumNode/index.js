const mysql=require('mysql');
var bodyParser=require('body-parser');
var urlencodedParse=bodyParser.urlencoded({extended: false});
const conn =mysql.createConnection({
  host: '127.0.0.1',
  user: 'mysql',
  database: 'nodeforum',
  password: 'mysql',
  port: '3307'
});

conn.connect(function(err){
  if(err){
    return console.log("error: "+ err.message);
  }else{
    console.log("Connection succesful");
  }
});


/////////////////////////////////////////
var express =require('express');

var app = express();

app.set('view engine', 'ejs');
cookieParser = require('cookie-parser');
app.use(cookieParser('secret key'));

app.get('/', function(req, res){
  conn.query("select * from box", (err, result, field)=>{
    console.log(result);
    res.render('index', {result: result});
  });

});
app.get('/about', function(req, res){
  res.render('about');
});

///accounts////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
app.get('/singups', function(req, res){
    res.render('reg', {error: false} );
});
app.post('/sing-up', urlencodedParse,  function(req, res){
  if(!req.body) return res.sendStatus(404);
  console.log(req.body);
conn.query("INSERT INTO user (name, password) VALUES ('"+req.body.logword+"' , '"+req.body.logPassword+"');", (err, result, field)=>{
    console.log(err);
    var log=req.body.logword.toString();
    var pass=req.body.logPassword.toString();
    if(!err){
      res.cookie('login', log);
      res.cookie('password', pass);
      res.cookie('status', "true");
      res.redirect('/profile');
    }else{
    res.render('reg', {error: true});
    }
  });

});
app.post('/sing-in', urlencodedParse,  function(req, res){
  if(!req.body) return res.sendStatus(404);
  console.log(req.body);
conn.query("select * from user where name='"+req.body.flname+"';", (err, result, field)=>{
    console.log(err);
    if(!result){

      console.log("vse propadlo.....................................................................");
      res.render('log', {status: "error"});
    }
    try{if(req.body.flPassword==result[0].password){
      console.log("urasaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
      var log=req.body.flname.toString();
      var pass=req.body.flPassword.toString();
      res.cookie('login', log);
      res.cookie('password', pass);
      res.cookie('status', "true");
      res.redirect('profile');
    }}catch{}
      res.render('log', {status: "error"});


  });
  });

app.get('/log', function(req, res){

    res.render('log', {status: ""});
});
app.get('/profile', function(req, res){


  if(req.cookies.status=="true"){

    conn.query("select * from user where name='"+req.cookies.login+"';", (err, result, field)=>{
conn.query("select * from box where author='"+req.cookies.login+"';", (err, result1, field)=>{
console.log(result1+"bbbbbbbbbbbbbbbbbbbbbbbbbbbb");
 res.render('profile', {result: req.cookies.login, list: result1});

});

     });
  }else {res.render('log', {status: ""})};
});

app.get('/log-out', function(req, res){
 res.clearCookie('login');
 res.clearCookie('password');
 res.clearCookie('status');
 res.redirect('log');
});

app.get('/news/profiles/:namepr', function(req, res){
 conn.query("select * from box where author='"+req.params.namepr+"';", (err, result1, field)=>{
 console.log(result1+"bbbbbbbbbbbbbbbbbbbbbbbbbbbb");
 res.render('aboutperson', {result: req.params.namepr, list: result1});
});
});
app.get('/profiles/:namepr', function(req, res){
 conn.query("select * from box where author='"+req.params.namepr+"';", (err, result1, field)=>{
 console.log(result1+"bbbbbbbbbbbbbbbbbbbbbbbbbbbb");
 res.render('aboutperson', {result: req.params.namepr, list: result1});
});
});
/////////////////////
app.get('/forum-add', function(req, res){
  res.render('forum-add', {stat: req.cookies.status});
});
app.get('/popular', function(req, res){
  res.sendFile(__dirname + "/popular.html");
});
app.get('/news/:id', function(req, res){
 conn.query("select * from box where id="+req.params.id, (err, result, field)=>{
   conn.query("select * from answers where id="+req.params.id, (err, result1, field)=>{

  res.render('news', {result: result, answers: result1, stat: req.cookies.status});
    });
  });
});

  app.post('/news/:id/answer', urlencodedParse,  function(req, res){
    if(!req.body) return res.sendStatus(404);
    console.log(req.body);
    conn.query("INSERT INTO answers (id, name, full_text) VALUES ("+req.params.id+", '"+req.cookies.login+"', '"+req.body.FullText+"');", (err, result, field)=>{
      //console.log(result);*/
      //console.log("ipoooooooooooooo"+res1);
      console.log(err);
      res.redirect('/news/'+req.params.id);
    });
    });
    app.post('/forum/add', urlencodedParse,  function(req, res){
      if(!req.body) return res.sendStatus(404);
      console.log(req.body);
    conn.query("INSERT INTO box (author, Anons, title, full_text) VALUES ('"+req.cookies.login+"' , '"+req.body.Anons+"' , '"+req.body.Title+"' , '"+req.body.FullText+"');", (err, result, field)=>{
        console.log(err);
        res.redirect('/');
      });

});

app.post('/searchs', urlencodedParse,  function(req, res){
  conn.query("SELECT * FROM box WHERE concat(anons , full_text , author , title) like '%"+req.body.ser+"%';", (err, result, field)=>{
    conn.query("SELECT * FROM answers WHERE concat(name , full_text) like '%"+req.body.ser+"%';", (err, result1, field)=>{
      conn.query("SELECT name FROM user WHERE name like '%"+req.body.ser+"%';", (err, result2, field)=>{
     res.render('search', {result: result, answers: result1, users: result2 });
       });
     });
   });
});
app.listen(3000);
